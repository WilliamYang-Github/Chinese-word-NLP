package org.pwstudio.nlp.model;

/**
 * 云问自己封装的机器学习模型接口
 * @author 李辰刚
 *
 */
public interface IModel {

}
