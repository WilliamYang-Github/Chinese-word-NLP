/**
 * 
 * 通用分类算法的所在包
 * 
 * @author iyunwen-李辰刚
 *
 */
package org.pwstudio.nlp.classification.vo;