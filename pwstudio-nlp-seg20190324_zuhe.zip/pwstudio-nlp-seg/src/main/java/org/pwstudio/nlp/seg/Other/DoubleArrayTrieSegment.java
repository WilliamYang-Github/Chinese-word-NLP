/*
 * <summary></summary>
 * <author>He Han</author>
 * <email>hankcs.cn@gmail.com</email>
 * <create-date>2014/12/23 21:34</create-date>
 *
 * <copyright file="AhoCorasickSegment.java">
 * This source is subject to the Apache License 2.0. see http://www.apache.org/licenses/LICENSE-2.0
 * </copyright>
 */
package org.pwstudio.nlp.seg.Other;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.pwstudio.nlp.collection.AhoCorasick.AhoCorasickDoubleArrayTrie;
import org.pwstudio.nlp.collection.trie.DoubleArrayTrie;
import org.pwstudio.nlp.corpus.tag.Nature;
import org.pwstudio.nlp.dictionary.CoreDictionary;
import org.pwstudio.nlp.dictionary.CustomDictionary;
import org.pwstudio.nlp.seg.DictionaryBasedSegment;
import org.pwstudio.nlp.seg.NShort.Path.AtomNode;
import org.pwstudio.nlp.seg.common.Term;

/**
 * 使用DoubleArrayTrie实现的最长分词器
 *
 * @author hankcs
 */
public class DoubleArrayTrieSegment extends DictionaryBasedSegment
{
    /**
     * 分词用到的trie树，可以直接赋值为自己的trie树（赋值操作不保证线程安全）
     */
    public DoubleArrayTrie<CoreDictionary.Attribute> trie;

    /**
     * 使用核心词库的trie树构造分词器
     */
    public DoubleArrayTrieSegment()
    {
        this(CoreDictionary.trie);
    }

    /**
     * 根据自己的trie树构造分词器
     *
     * @param trie
     */
    public DoubleArrayTrieSegment(DoubleArrayTrie<CoreDictionary.Attribute> trie)
    {
        super();
        this.trie = trie;
        config.useCustomDictionary = false;
    }

    @Override
    protected List<Term> segSentence(char[] sentence)
    {
        char[] charArray = sentence;
        final int[] wordNet = new int[charArray.length];
        Arrays.fill(wordNet, 1);
        final Nature[] natureArray = config.speechTagging ? new Nature[charArray.length] : null;
        matchLongest(sentence, wordNet, natureArray, trie);
        if (config.useCustomDictionary)
        {
            matchLongest(sentence, wordNet, natureArray, CustomDictionary.dat);
            if (CustomDictionary.trie != null)
            {
                CustomDictionary.trie.parseLongestText(charArray, new AhoCorasickDoubleArrayTrie.IHit<CoreDictionary.Attribute>()
                {
                    @Override
                    public void hit(int begin, int end, CoreDictionary.Attribute value)
                    {
                        int length = end - begin;
                        if (length > wordNet[begin])
                        {
                            wordNet[begin] = length;
                            if (config.speechTagging)
                            {
                                natureArray[begin] = value.nature[0];
                            }
                        }
                    }
                });
            }
        }
        LinkedList<Term> termList = new LinkedList<Term>();
        if (config.speechTagging)
        {
            for (int i = 0; i < natureArray.length; )
            {
                if (natureArray[i] == null)
                {
                    int j = i + 1;
                    for (; j < natureArray.length; ++j)
                    {
                        if (natureArray[j] != null) break;
                    }
                    List<AtomNode> atomNodeList = quickAtomSegment(charArray, i, j);
                    for (AtomNode atomNode : atomNodeList)
                    {
                        if (atomNode.sWord.length() >= wordNet[i])
                        {
                            wordNet[i] = atomNode.sWord.length();
                            natureArray[i] = atomNode.getNature();
                            i += wordNet[i];
                        }
                    }
                    i = j;
                }
                else
                {
                    ++i;
                }
            }
        }
        for (int i = 0; i < wordNet.length; )
        {
            Term term = new Term(new String(charArray, i, wordNet[i]), config.speechTagging ? (natureArray[i] == null ? Nature.nz : natureArray[i]) : null);
            term.offset = i;
            termList.add(term);
            i += wordNet[i];
        }
        return termList;
    }

    private void matchLongest(char[] sentence, int[] wordNet, Nature[] natureArray, DoubleArrayTrie<CoreDictionary.Attribute> trie)
    {
        DoubleArrayTrie<CoreDictionary.Attribute>.LongestSearcher searcher = trie.getLongestSearcher(sentence, 0);
        while (searcher.next())
        {
            wordNet[searcher.begin] = searcher.length;
            if (config.speechTagging)
            {
                natureArray[searcher.begin] = searcher.value.nature[0];
            }
        }
    }
}
