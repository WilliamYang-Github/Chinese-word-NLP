/*
 * <summary></summary>
 * <author>hankcs</author>
 * <email>me@hankcs.com</email>
 * <create-date>2015/5/4 23:36</create-date>
 *
 * <copyright file="BasicTokenizer.java">
 * Copyright (c) 2003-2015, hankcs. All Right Reserved, http://www.hankcs.com/
 * </copyright>
 */
package org.pwstudio.nlp.tokenizer;

import java.util.List;

import org.pwstudio.nlp.PwNLP;
import org.pwstudio.nlp.seg.Segment;
import org.pwstudio.nlp.seg.common.Term;

/**
 * 基础分词器，只做基本NGram分词，不识别命名实体，不使用用户词典
 * @author hankcs
 */
public class BasicTokenizer
{
    /**
     * 预置分词器
     */
    public static final Segment SEGMENT = PwNLP.newSegment().enableAllNamedEntityRecognize(false).enableCustomDictionary(false);

    /**
     * 分词
     * @param text 文本
     * @return 分词结果
     */
    public static List<Term> segment(String text)
    {
        return SEGMENT.seg(text.toCharArray());
    }

    /**
     * 分词
     * @param text 文本
     * @return 分词结果
     */
    public static List<Term> segment(char[] text)
    {
        return SEGMENT.seg(text);
    }

    /**
     * 切分为句子形式
     * @param text 文本
     * @return 句子列表
     */
    public static List<List<Term>> seg2sentence(String text)
    {
        return SEGMENT.seg2sentence(text);
    }
}
